package com.mytech.backend.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendOgApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendOgApplication.class, args);
	}

}
